import os
from datetime import datetime
import yfinance
import yahoo_fin
import boto3
import 

def handler(event, context):
    
    try:
        
        sns_topic_arn = os.environ['arn:aws:sns:us-east-1:794038237701:lambdaExecResult']
        sns_client = boto3.client('sns')
        
        message = "Hello from Lambda!"
        
        response = sns_client.publish(
            TopicArn=sns_topic_arn,
            Message=message,
            Subject="Lambda SNS Test"
        )
        
        return {
            'statusCode': 200,
            'body': f'The current time is: {datetime.now()}'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': f'Error: {str(e)}'
        }
