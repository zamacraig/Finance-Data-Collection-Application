def sample_utility_function():
    return "This is a sample utility function."
